<?php
return [
		'app/page-modules',
		'app/theme',
	];
