<?php
/**
 * Main Navigation snippet
 *
 * @param $location
 *
 */
?>
<nav  style="display:none;" id="site-navigation" role="navigation" aria-label="<?= __('Main navigation', 'theme-blank') ?>">

</nav>


<nav class="fuu" style="margin-top:30px;" id="site-navigation" role="navigation" aria-label="<?= __('mobile', 'theme-blank') ?>">

</nav>
