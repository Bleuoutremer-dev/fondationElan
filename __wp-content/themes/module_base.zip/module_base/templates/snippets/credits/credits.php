<?php 
/**
 * Kaven Martineau credits snippet
 *
 */	
?>
<div class="credits">
	<a href="http://kavenmartineau.com" class="credits-by" title="Design et développement par Kaven Martineau">
		Design et développement par <?= sprite('') ?>
	</a>
</div>