<section class="CTA big-section parallax wow animate__fadeIn" data-parallax-background-ratio="0.1" style="background-image:url('<?= $image_CTA ?>');">
    <div class="opacity-full "></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-xl-8 col-lg-10 col-md-11 position-relative text-center wow animate__zoomIn" data-wow-delay="0.4s">
                <h2 class="alt-font font-weight-500 text-white letter-spacing-minus-2px margin-50px-bottom md-margin-40px-bottom"><?= $titre_CTA ?></h2>
                <a href="<?= $lien_savoir_plus_cta ?>" target="<?= $preference_lien_savoirplus_cta ?>" class="btn-rond"><span><strong><?= $texte_boutonCTA ?></strong></span></a>
            </div>
        </div>
    </div>
</section>