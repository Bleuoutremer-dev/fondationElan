<section class="grostitre <?= $couleurdefondGT ?> deuximagestextes wow animate__fadeIn">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 col-lg-12 md-margin-5-rem-bottom xs-margin-5-rem-top wow animate__fadeIn">
                       <?php if ($petittitrebarre  ): ?>
                <div class="sectionpetittitre alt-font text-medium font-weight-500 margin-30px-bottom d-flex">
                    <span class="w-60px h-3px bg-tussock opacity-7 align-self-center margin-20px-right flex-shrink-0">   
                    </span>
                    <div class="petittitre media-body flex-grow-1">
                        <span class="text-tussock text-uppercase" style="color:#4BDBC6; font-weight:600;"><?= $petittitrebarre ?>
                        </span>
                    </div>
                </div>
                 <?php endif ?>  


                    <!-- start accordion item -->
                   <h3 class="grostitre_deco alt-font text-extra-dark-gray font-weight-600 w-85 margin-35px-bottom lg-w-100 sm-margin-25px-bottom">
                    <span class="un"><?= $grostitreligneun ?></span>
                    <span class="<?= $couleurelementdeco ?>" style="color:<?= $couleurdetitre ?>"><?= $grostitrelignedeux ?></span>
                </h3>
                       
    
            </div>
        </div>
    </div>
</section>