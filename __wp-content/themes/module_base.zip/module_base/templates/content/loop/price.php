<?php if ( is_product_purchasable() ): ?>
<span class="loop-product-price price"><?= get_price() ?></span>
<?php endif; ?>