<h3 class="loop-product-title"><?= $nom_projet ?></h3>
