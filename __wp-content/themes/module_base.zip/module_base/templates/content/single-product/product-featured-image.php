<div class="single-product--image" style="background-image: url(<?php the_post_thumbnail_url() ?>)">
	<?php the_post_thumbnail() ?>
</div>