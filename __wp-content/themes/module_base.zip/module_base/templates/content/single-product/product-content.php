<div class="single-product--content">
	<h2>Description</h2>
	<?php the_content() ?>
</div>
