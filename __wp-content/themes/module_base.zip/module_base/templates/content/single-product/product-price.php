<div class="single-product--price price">
	<?= get_price() ?>
</div>