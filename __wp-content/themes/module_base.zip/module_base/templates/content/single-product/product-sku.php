<div class="single-product--sku">
	<h2>Code</h2>
	<p itemprop="sku"><?php the_field('product_sku') ?></p>
</div>