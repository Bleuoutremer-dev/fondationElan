<?php
/**
 * Template Name: Page modulaire
 *
 * @package theme-blank
 * @since theme-blank 0.1.0
 */
get_header(); 

	the_snippet('module-related/page-modules-loop');
	
get_footer();
