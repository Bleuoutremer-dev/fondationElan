<section class="banniere-section cover-background bg-light-gray">
    <div class="opacity-extra-medium-2 bg-light-gray slate-blue"></div>
    <div class="<?= $preference_bulles ?>"></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-xl-7 col-lg-8 col-md-10 position-relative text-center overlap-gap-section">
                <h2 class="alt-font text-white font-weight-600  wow animate__fadeIn"><?= $titre_banniere ?></h2>
            </div>
        </div>
    </div>
</section>