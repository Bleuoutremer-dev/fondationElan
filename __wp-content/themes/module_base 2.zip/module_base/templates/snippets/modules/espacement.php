<div class="<?= $couleurespacement  ?>">
   <div class="espacementsection"></div>
</div>

