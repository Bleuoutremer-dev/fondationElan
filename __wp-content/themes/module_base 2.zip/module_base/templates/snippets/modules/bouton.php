<section class="boutonsection big-section wow animate__fadeIn <?= $optioncouleurfond ?>" >
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-xl-8 col-lg-10 col-md-11  text-center wow animate__zoomIn" data-wow-delay="0.4s">
                   <a href="<?= $lien_savoir_plus_pieddepage ?>" target="<?= $preference_lien_savoirplus_pieddepage ?>"class="btn-rond" style="background-color:<?= $optioncouleur ?> !important;  color:<?= $optioncouleurtexte ?>;"><span><strong><?= $texte_boutonpieddepage?></strong></span></a>
               </div>
            </div>
        </div>
    </div>
</section>