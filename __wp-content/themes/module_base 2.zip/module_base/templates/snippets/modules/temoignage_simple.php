<section class="temoignage moyen-section wow animate__fadeIn bg-light-gray">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-xl-10 col-lg-12 col-md-10">
                    <div class="row">
                <div class="col-xl-5 col-lg-5  col-12" style="margin-left">
                </div>
                <div class="col-xl-7 col-lg-7 col-12" style="margin-left">
                <h2 class="grostextevert alt-font text-left" style="color:#50D9C2;">Témoignages<span style="position: relative; bottom: -5px; margin-left: 20px;color:#919191; font-size:24px; letter-spacing:3px; font-weight:600px;"><sup><strong>EN BREF</strong></sup></span></h2>
                </div>
                    </div>
                <div class="swiper-simple-arrow-style-1">
                    <div class="swiper-container black-move" data-slider-options='{ "loop": true, "slidesPerView": 1, "spaceBetween": 0, "observer": true, "observeParents": true, "keyboard": { "enabled": true, "onlyInViewport": true }, { "delay": 8000, "disableOnInteraction": false }, "effect": "slide" }'>
                        <div class="swiper-wrapper">
  
                            <!-- start testimonial item -->
                      
                                    <div class="swiper-slide text-center">
                                        <div class="feature-box feature-box-left-icon-middle">
            
                                            <div class="row padding50">
                                                <div class="col-xl-5 col-lg-5 col-12" style="position:relative; z-index:-5;">
                                                    <div class="feature-box-icon temoignagebefore">
                                                        <img class="rounded-circle " src="<?= $photo_carouselseul ?>" alt="<?= $altcarouselseul ?>"style="border: solid 20px #ffffff;" />
                                                    </div>
                                                </div>
                                                <div class="col-xl-7 col-lg-7 col-12">
                                                    <div class="feature-box-content">
                                          
                                                        <p class="w-85 lg-w-100">
                                                            <strong><?= $carouselboldseul ?></strong></p>
                                                        <p class="w-85 lg-w-100">
                                                            <?= $Bloc_texte_carouselseul ?></p>
                                                        <div class="text-extra-dark-gray alt-font text-uppercase font-weight-600"><span><?= $carouselboldseul ?></span></div>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
   
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>