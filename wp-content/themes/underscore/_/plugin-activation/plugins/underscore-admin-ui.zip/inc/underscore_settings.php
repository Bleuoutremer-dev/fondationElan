<?php

add_action( 'admin_enqueue_scripts', 'mw_enqueue_color_picker' );
function mw_enqueue_color_picker( $hook_suffix ) {
    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_script( 'my-script-handle', plugins_url('underscore-colorpicker.js', __FILE__ ), array( 'wp-color-picker' ), false, true );
}

// Customize Fancy Admin UI Colors
$underscore_color_settings = new underscore_color_settings();
class underscore_color_settings {
    function __construct( ) {
        add_filter( 'admin_init' , array( &$this , 'register_fields' ) );
    }
    function register_fields() {
        register_setting( 'general', 'underscore_primary_color', 'esc_attr' );
        add_settings_field('underscore_primary_color', '<label for="underscore_primary_color">'.__('Admin UI Primary Color:' , 'underscore_primary_color' ).'</label>' , array(&$this, 'fields_html') , 'general' );
    }
    function fields_html() {
        $value = get_option( 'underscore_primary_color', '' );
        echo '<input type="text" id="underscore_primary_color" name="underscore_primary_color" value="' . $value . '" data-default-color="#000000" />';
        echo "
          <script>
            jQuery(document).ready(function($){
              $('#underscore_primary_color').wpColorPicker();
            });
          </script>
          ";
    }
}

$underscore_secondary_color_settings = new underscore_secondary_color_settings();
class underscore_secondary_color_settings {
    function __construct( ) {
        add_filter( 'admin_init' , array( &$this , 'register_fields' ) );
    }
    function register_fields() {
        register_setting( 'general', 'underscore_secondary_color', 'esc_attr' );
        add_settings_field('underscore_secondary_color', '<label for="underscore_secondary_color">'.__('Admin UI Secondary Color:' , 'underscore_secondary_color' ).'</label>' , array(&$this, 'fields_html') , 'general' );
    }
    function fields_html() {
        $value = get_option( 'underscore_secondary_color', '' );
        echo '<input type="text" id="underscore_secondary_color" name="underscore_secondary_color" value="' . $value . '" data-default-color="#cc551a" />';
        echo "
          <script>
            jQuery(document).ready(function($){
              $('#underscore_secondary_color').wpColorPicker();
            });
          </script>
          ";
    }
}