<?php
/*
  Plugin Name:  Underscore - Admin UI
  Plugin URI:   http://transistordesign.com
  Description:  Clean admin, based on FAU by Bob Orchard
  Version:      2.0.1
  Author:       Transistor design
  Author URI:   http://transistordesign.com
  */

include_once('inc/underscore_settings.php');

// Include Admin Styles
function underscore_admin_theme_style() {
  wp_enqueue_style( 'underscore-admin-theme', plugins_url( 'css/underscore-styles-admin.php', __FILE__ ) );
  wp_enqueue_style( 'underscore-adminbar', plugins_url( 'css/underscore-styles-adminbar.php', __FILE__ ) );
}
add_action( 'admin_enqueue_scripts', 'underscore_admin_theme_style' );

function underscore_adminbar_style() {
	
	if ( is_user_logged_in() )
  	wp_enqueue_style( 'underscore-admin-theme', plugins_url( 'css/underscore-styles-adminbar.php', __FILE__ ) );
  	
}
add_action( 'wp_enqueue_scripts', 'underscore_adminbar_style' );

// Login Page Styling
function underscore_login_theme_style() {
  wp_enqueue_style( 'underscore-login-theme', plugins_url( 'css/underscore-styles-login.php', __FILE__ ) );
  wp_enqueue_script( 'underscore-login-theme', plugins_url( 'css/underscore-styles-login.php', __FILE__ ) );
}
add_action( 'login_enqueue_scripts', 'underscore_login_theme_style' );

// Update Admin Footer
function underscore_swap_footer_admin() {
  echo '<p>Support technique : <a href="mailto:support@transistordesign.com" target="_blank">support@transistordesign.com</a></p>';
}
add_filter( 'admin_footer_text', 'underscore_swap_footer_admin' );

// Remove deunderscorelt HTML height on the admin bar callback
function underscore_admin_bar_style() {
  if ( is_admin_bar_showing() ) {
?>
  <style type="text/css" media="screen">
    html { margin-top: 46px !important; }
    * html body { margin-top: 46px !important; }
  </style>
<?php } }
add_theme_support( 'admin-bar', array( 'callback' => 'underscore_admin_bar_style' ) );

function fontawesome_dashboard() {
   wp_enqueue_style('fontawesome', 'http:////netdna.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.css', '', '4.5.0', 'all');
}

add_action('admin_init', 'fontawesome_dashboard');