<?php
  header("Content-type: text/css; charset: UTF-8");

  require_once('../../../../wp-config.php');

  if(get_option( 'underscore_primary_color') != ""):
    $underscore_primary    = get_option( 'underscore_primary_color');
  else :
    $underscore_primary    = "#000000";
  endif;
  if(get_option( 'underscore_secondary_color') != ""):
    $underscore_secondary  = get_option( 'underscore_secondary_color');
  else :
    $underscore_secondary    = "#cc551a";
  endif;
?>

body, html {
background: <?php echo $underscore_primary; ?>
}

.login h1 a { display:none }

.login #login_error a,.login label,
.login #backtoblog a,.login #nav a {
	color:#FFF
}

.login label,
input[type=checkbox]:checked:before {
	color: <?php echo $underscore_primary; ?>
}

.login label,
.login #nav,
.login #backtoblog {
	display:block;
}

.login #nav,
.login #backtoblog {
	text-align:center	
}

.login #nav a:hover,
.login #backtoblog a:hover {
	color:#FFF;
	text-decoration:underline
}

.login form .input,.login input[type=text] {
	margin-top:5px;
	display:block
}


.login form .input, .login input[type=text] {
	font-size: 18px;
	line-height: 1em;
	padding: 10px
}


.wp-core-ui #loginform .button-primary,
.wp-core-ui .button-primary, .wp-core-ui .button-primary.focus,
.wp-core-ui .button-primary.hover, 
.wp-core-ui .button-primary:focus, .wp-core-ui .button-primary:hover {
	
	font-weight: 300;
	letter-spacing: 0.05em;
	
	border-color: transparent;
	-webkit-box-shadow: none;
	box-shadow: none;
	text-shadow: none;
	
	transition: all 300ms ease;
}

.wp-core-ui .button.button-large:hover {
	background:<?php echo $underscore_secondary; ?>;
}

.login form .forgetmenot {
	float:none
}

#loginform,.login #login_error,.login .message {
	color:<?php echo $underscore_primary; ?>;
	background:#FFF
}

#loginform {
	padding: 32px 30px 30px;
}

.wp-core-ui .button-group.button-large .button,
.wp-core-ui .button.button-large {
	background:<?php echo $underscore_primary; ?>;
	color:#FFF;
	height:auto;
	font-size:18px;
	margin-top: 30px;
	padding:10px 0;
	width:100%
}


.login input[type=text], 
.login input[type=password],
.login input[type=checkbox] {
	box-shadow: none;
	transition: all 300ms ease;
	background: #FFF;
}


input[type=text]:focus, input[type=search]:focus, input[type=radio]:focus, input[type=tel]:focus, input[type=time]:focus, input[type=url]:focus, input[type=week]:focus, input[type=password]:focus, input[type=checkbox]:focus, input[type=color]:focus, input[type=date]:focus, input[type=datetime]:focus, input[type=datetime-local]:focus, input[type=email]:focus, input[type=month]:focus, input[type=number]:focus, select:focus, textarea:focus {
	border-color: <?php echo $underscore_primary; ?>;
	box-shadow: none;
}
