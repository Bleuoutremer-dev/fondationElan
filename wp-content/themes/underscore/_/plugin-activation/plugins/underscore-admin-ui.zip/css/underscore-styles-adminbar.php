<?php
  header("Content-type: text/css; charset: UTF-8");

  require_once('../../../../wp-config.php');

  if(get_option( 'underscore_primary_color') != ""):
    $underscore_primary    = get_option( 'underscore_primary_color');
  else :
    $underscore_primary    = "#000000";
  endif;
  if(get_option( 'underscore_secondary_color') != ""):
    $underscore_secondary  = get_option( 'underscore_secondary_color');
  else :
    $underscore_secondary    = "#cc551a";
  endif;
?>
html.wp-toolbar {
	padding-top: 56px !important
}

.admin-bar.masthead-fixed .site-header {
  top: 46px!important;
}

#wp-admin-bar-site-name {
	width: calc( 180px - 9px );
}
	#wpadminbar #wp-admin-bar-site-name a:before {
		display:inline-block;
		color:<?php echo $underscore_primary; ?>;
		background: #FFF;
		border-radius: 100%;
		padding: 5px;
		
		text-align:center;
		line-height: 1em;
	}



#wpadminbar #wp-admin-bar-my-sites a.ab-item, #wpadminbar #wp-admin-bar-site-name a.ab-item {
	overflow: visible;
}

#wp-admin-bar-root-default li {
	border-right: 1px solid rgba(0,0,0,0.3);	
}

.wp-admin #wpadminbar #wp-admin-bar-site-name>.ab-item:before {
	content: "\f328";
	margin-right: 10px;
}

.wp-admin #wpadminbar #wp-admin-bar-new-content > .ab-item .ab-icon {
	padding-top:0 !important;
	-webkit-font;
}
.wp-admin #wpadminbar #wp-admin-bar-new-content > .ab-item .ab-icon:before {
	content: "\f055";
	font-family: Fontawesome !important;
}

#wpadminbar {
	background:<?php echo $underscore_primary; ?>;
	height: 56px
}

#wpadminbar .quicklinks .menupop ul li a:focus,#wpadminbar .quicklinks .menupop ul li a:focus strong,#wpadminbar .quicklinks .menupop ul li a:hover,#wpadminbar .quicklinks .menupop ul li a:hover strong,#wpadminbar .quicklinks .menupop.hover ul li a:focus,#wpadminbar .quicklinks .menupop.hover ul li a:hover,#wpadminbar li .ab-item:focus:before,#wpadminbar li a:focus .ab-icon:before,#wpadminbar li.hover .ab-icon:before,#wpadminbar li.hover .ab-item:before,#wpadminbar li:hover #adminbarsearch:before,#wpadminbar li:hover .ab-icon:before,#wpadminbar li:hover .ab-item:before,#wpadminbar.nojs .quicklinks .menupop:hover ul li a:focus,#wpadminbar.nojs .quicklinks .menupop:hover ul li a:hover {
color:#FFF
}

#wpadminbar ul li {
	padding: 12px 4px
}

#wpadminbar ul li:hover {
background:<?php echo $underscore_secondary; ?>
}

#wpadminbar .menupop .ab-sub-wrapper,#wpadminbar .shortlink-input {
margin-top:12px;
left:0
}

#wpadminbar .ab-submenu {
padding:0
}

#wpadminbar #adminbarsearch:before,#wpadminbar .ab-icon:before,#wpadminbar .ab-item:before,#wpadminbar #wp-admin-bar-user-info .username {
color:#FFF
}

#wpadminbar:not(.mobile) .ab-top-menu>li.hover>.ab-item,
#wpadminbar:not(.mobile) .ab-top-menu>li:hover>.ab-item,
#wpadminbar:not(.mobile) .ab-top-menu>li>.ab-item:focus,
#wpadminbar.nojq .quicklinks .ab-top-menu>li>.ab-item:focus {
background:transparent
}

#wpadminbar .menupop .ab-sub-wrapper,#wpadminbar .shortlink-input {
background:<?php echo $underscore_primary; ?>
}

#wpadminbar a.ab-item,#wpadminbar>#wp-toolbar span.ab-label,#wpadminbar>#wp-toolbar span.noticon {
color:#FFF!important
}

#wpadminbar ul#wp-admin-bar-root-default>li#wp-admin-bar-wp-logo {
display:none
}

#wpadminbar .quicklinks li#wp-admin-bar-my-account.with-avatar>a img {
float:left;
margin:3px 15px;
width:24px;
height:24px;
border:1px solid #FFF;
border-radius:50%
}

#wpadminbar .dashicons,#wpadminbar .dashicons-before:before {
font-size:30px;
height:30px;
width:30px
}

#wpadminbar a.ab-item .icon:before {
font-size:20px;
vertical-align:middle!important;
padding:6px 4px 0 0
}



#wpadminbar ul li#wp-admin-bar-my-account {
	padding: 12px 14px;
}

#wpadminbar .quicklinks li#wp-admin-bar-my-account.with-avatar > a img {
	border:0;
	width: 28px;
	height: 28px;
	margin: 3px 10px 3px 0;
}

#wpadminbar #wp-admin-bar-my-account.with-avatar>.ab-empty-item img, #wpadminbar #wp-admin-bar-my-account.with-avatar>a img {
	background: transparent;
}
