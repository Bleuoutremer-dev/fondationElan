<?php
  header("Content-type: text/css; charset: UTF-8");

  require_once('../../../../wp-config.php');

  if(get_option( 'underscore_primary_color') != ""):
    $underscore_primary    = get_option( 'underscore_primary_color');
  else :
    $underscore_primary    = "#000000";
  endif;
  if(get_option( 'underscore_secondary_color') != ""):
    $underscore_secondary  = get_option( 'underscore_secondary_color');
  else :
    $underscore_secondary    = "#cc551a";
  endif;

?>

#wp-auth-check-wrap #wp-auth-check {
	background-color: <?php echo $underscore_primary; ?>;
}

a,
input[type=checkbox]:checked:before,
.view-switch a.current:before {
color:<?php echo $underscore_primary; ?>
}

a:hover {
color:<?php echo $underscore_secondary; ?>
}

#adminmenu {
margin:0
}




#adminmenu, 
#adminmenu .wp-submenu, 
#adminmenuback, 
#adminmenuwrap {
	width: 180px
}

#adminmenu .wp-not-current-submenu .wp-submenu, .folded #adminmenu .wp-has-current-submenu .wp-submenu {
	min-width: 180px
}

#adminmenu .wp-submenu {
	left: 179px;

	box-shadow: 1px 1px 5px 1px rgba(0,0,0,.2);	
	
}


#adminmenu li.menu-top {
	border-right: 1px solid #e4e4e4;
}
	#adminmenu li.menu-top.wp-menu-open {
		border-right-color: #F1F1F1;
	}
	
#wpcontent, #wpfooter {
	margin-left: 180px
}




/* Fixes issue caused by WP V4.2.2 */
#adminmenu div.wp-menu-image:before {
  color: #a0a5aa;
  color: rgb(160,165,170);
}

#adminmenu li a:focus div.wp-menu-image:before,#adminmenu li.opensub div.wp-menu-image:before,#adminmenu li:hover div.wp-menu-image:before,
#adminmenu .wp-submenu a:focus, #adminmenu .wp-submenu a:hover, #adminmenu a:hover, #adminmenu li.menu-top>a:focus {
  color: <?php echo $underscore_primary; ?>!important;
}

#adminmenuback,
#adminmenu {
	background: #FFF;
}

#adminmenu .wp-submenu,#adminmenuwrap,/* Sub Menu */
#adminmenu .wp-has-current-submenu .wp-submenu,#adminmenu .wp-has-current-submenu .wp-submenu.sub-open,#adminmenu .wp-has-current-submenu.opensub .wp-submenu,#adminmenu a.wp-has-current-submenu:focus+.wp-submenu,.no-js li.wp-has-current-submenu:hover .wp-submenu {
	background: #f1f1f1
}

#adminmenu .wp-has-current-submenu .wp-submenu .wp-submenu-head,#adminmenu .wp-menu-arrow,#adminmenu .wp-menu-arrow div,#adminmenu li.current a.menu-top,#adminmenu li.wp-has-current-submenu a.wp-has-current-submenu,.folded #adminmenu li.current.menu-top,.folded #adminmenu li.wp-has-current-submenu,/* Hover actions */
#adminmenu li.menu-top:hover,#adminmenu li.opensub>a.menu-top,#adminmenu li>a.menu-top:focus {
	background: #F1F1F1;
}

#adminmenu .opensub .wp-submenu li.current a,#adminmenu .wp-submenu li.current,#adminmenu .wp-submenu li.current a,#adminmenu .wp-submenu li.current a:focus,#adminmenu .wp-submenu li.current a:hover,#adminmenu a.wp-has-current-submenu:focus+.wp-submenu li.current a,#adminmenu .wp-submenu .wp-submenu-head,/* Dashicons */
#adminmenu .current div.wp-menu-image:before,#adminmenu .wp-has-current-submenu div.wp-menu-image:before,#adminmenu a.current:hover div.wp-menu-image:before,#adminmenu a.wp-has-current-submenu:hover div.wp-menu-image:before,#adminmenu li.wp-has-current-submenu:hover div.wp-menu-image:before, #adminmenu li:hover div.wp-menu-image:before {
	color:<?php echo $underscore_primary; ?>
}






#adminmenu li.wp-has-current-submenu a.wp-has-current-submenu {
padding-bottom:0
}

#adminmenu .wp-has-current-submenu ul>li>a {
padding-left:34px
}

#adminmenu .wp-submenu a {
color:#666
}




#adminmenuwrap #adminmenu li.wp-menu-separator {
	display: block;
	margin: 0;
	height: 3px;
	padding: 0;
	background: #e4e4e4;
}
	#adminmenuwrap #adminmenu li.wp-menu-separator .separator {
		height: 2px;
		-background: red;
	}

#adminmenu .wp-submenu-head,#adminmenu a.menu-top {
padding:7px 0
}

.folded #adminmenu .wp-submenu-head,.folded #adminmenu a.menu-top {
padding:5px 0
}

#adminmenu .wp-not-current-submenu .wp-submenu,.folded #adminmenu .wp-has-current-submenu .wp-submenu {
padding:10px
}

#adminmenu li.wp-has-current-submenu a.wp-has-current-submenu div.wp-menu-name {
	color:<?php echo $underscore_primary; ?>
}

ul#adminmenu a.wp-has-current-submenu:after,ul#adminmenu>li.current>a.current:after,#adminmenu li.wp-has-submenu.wp-not-current-submenu.opensub:hover:after {
display:none
}

#adminmenu li.menu-top {
border-bottom:1px solid #e4e4e4
}

#adminmenu div.wp-menu-name {
color:#666
}

.wrap h1 {
	padding-top: 1em;
}
.wrap h2 {
	font-size:30px;
	line-height: 1em;
	font-weight:100;
	padding:30px 25px 24px 0;
		padding-top:0;
}

.wrap .add-new-h2, .wrap .add-new-h2:active, 
.wrap .page-title-action, .wrap .page-title-action:active {
	color:<?php echo $underscore_primary; ?>	
}


.wrap .add-new-h2,
.wrap .add-new-h2:active {
	background:<?php echo $underscore_primary; ?>;
	color:#FFF;
	top:-8px
}

.wrap .add-new-h2:hover {
background:<?php echo $underscore_secondary; ?>
}

#titlediv #title-prompt-text {
font-size:1.2em;
font-weight:100
}

div.updated {
border:1px solid #e1e1e1;
border-left:5px solid <?php echo $underscore_primary; ?>;
-webkit-box-shadow:none;
box-shadow:none
}

input[type=email],input[type=number],input[type=password],input[type=search],input[type=tel],input[type=text],input[type=url],select,textarea {
box-shadow:none
}

.postbox {
border:1px solid #e1e1e1
}

.menu.ui-sortable .menu-item-handle,.meta-box-sortables.ui-sortable .hndle {
background:#f5f5f5
}

#major-publishing-actions {
	background:#FFF;
	padding:0;
	
	display: flex;
	justify-content: space-between;
	align-items: center;
    
}

#delete-action {
	__float: none;
	padding: 0;
	text-align: left;
	margin: 1em;
	margin-left: 2em;
}

#delete-action a {
text-decoration:underline
}

#publishing-action {
	flex-grow: 1;
	flex-shrink: 0;
	margin: 1em;
	position: relative;
}

#publishing-action .spinner {
	position:absolute;
	top: 0.5em;
	background-position:top center;
	padding: 1em 0;
}

#publishing-action #publish {
	float:none;
	font-size:15px;
	height:auto;
	padding:0.75em 1.25em;
	width:100%
}

.wp-core-ui .button,.wp-core-ui .button-primary,.wp-core-ui .button-secondary {
	-moz-border-radius:0;
	-webkit-border-radius:0;
	border-radius:0;
	box-shadow:none;
	border:0
}

.wp-core-ui .button,.wp-core-ui .button-secondary {
background:#e4e4e4
}

.wp-core-ui .button:hover,.wp-core-ui .button-secondary:hover,.wp-core-ui .button-primary,
.wrap .add-new-h2:hover, .wrap .page-title-action:hover,
.wp-core-ui .button-primary.active, .wp-core-ui .button-primary.active:focus, .wp-core-ui #wpbody .button-primary.active:hover, .wp-core-ui #wpbody .button-primary:active,
.wp-core-ui .button-primary.focus, .wp-core-ui .button-primary.hover, .wp-core-ui .button-primary:focus, .wp-core-ui .button-primary:hover {
	background:<?php echo $underscore_primary; ?>;
	color:#FFF;
	border-color: transparent;
	
	text-shadow:none;
	outline: none;
	box-shadow: none;
}

a,
input,
#publishing-action #publish {
	transition: all 300ms ease;
}
#publishing-action #publish:hover {
	background:<?php echo $underscore_secondary; ?>;
}

.wp-core-ui .button-primary.focus, .wp-core-ui .button-primary.hover, .wp-core-ui .button-primary:focus, .wp-core-ui .button-primary:hover {
	
}

.wp-core-ui .button-primary-disabled, .wp-core-ui .button-primary.disabled, .wp-core-ui .button-primary:disabled, .wp-core-ui .button-primary[disabled] {
	color:#FFF !important;
	background:<?php echo $underscore_primary; ?> !important;
	color:#FFF;
	opacity: 0.5;
}


.wrap .add-new-h2, .wrap .add-new-h2:active, .wrap .page-title-action, .wrap .page-title-action:active {
	padding: 6px 10px;	
}


.wp-core-ui .button, .wp-core-ui .button-primary, .wp-core-ui .button-secondary {
	line-height: 30px;
	height: 36px;
	padding: 3px 14px 3px;
	border-radius: 4px;
}

.wp-core-ui .button:hover span.wp-media-buttons-icon:before,.wp-core-ui .button-secondary:hover span.wp-media-buttons-icon:before {
color:#FFF
}

.wp-media-buttons .insert-media {
font-size:12px
}

.wp-media-buttons .add_media span.wp-media-buttons-icon:before {
font-size:14px!important
}

div.mce-toolbar-grp,.html-active .switch-html,.tmce-active .switch-tmce {
background:#FFF!important
}

#acf-col-right {
display:none
}

#acf-col-left {
margin:0!important
}

.vc_navbar.subnav-fixed {
top:40px!important
}

.composer-switch a,.composer-switch a:visited,.composer-switch a.wpb_switch-to-front-composer,.composer-switch a:visited.wpb_switch-to-front-composer,.composer-switch .logo-icon {
background-color:<?php echo $underscore_primary; ?>!important
}

.composer-switch .vc-spacer, .composer-switch a.wpb_switch-to-composer:hover, .composer-switch a:visited.wpb_switch-to-composer:hover, .composer-switch a.wpb_switch-to-front-composer:hover, .composer-switch a:visited.wpb_switch-to-front-composer:hover {
background-color: <?php echo $underscore_secondary; ?>!important
}



.tablenav {

	position: relative;
	top: 1em;
	
  -background: whitesmoke;
  -border-radius: 0.25em;
  
  padding: 1em 1em 0.5em;
  margin: 2em 0;
	
	height: 50px;
	
	box-shadow: 0 1px 1px rgba(0,0,0,.04);
	border: 1px solid #e5e5e5;
	background: #fff;
	
}

.wp-admin select,
#contextual-help-link-wrap, #screen-options-link-wrap,
.search-box input[name="s"], .tablenav .search-plugins input[name="s"], .tagsdiv .newtag {
	height: 36px;
}

.tagsdiv .newtag {
	width: 160px;
}

input, select {
	padding: 7px 10px;
	border-radius: 4px;
}

.tablenav .actions select {
	min-width: 140px;
}


.wp-core-ui .button-link:focus, .wp-core-ui .button-secondary:focus, .wp-core-ui .button.focus, .wp-core-ui .button:focus {
	border:0;
	box-shadow:none;
}





#update-nag, .update-nag {
	background: rgba(255,255,0,0.2);
	border: 1px solid #ffba00;
	border-left-width: 8px;
	
	-webkit-box-shadow: none;
					box-shadow: none;
}

.notice,
div.error,
div.updated {
	background: rgba(0,0,255,0.1);
	border: 1px solid #0f1f77;
	border-left-width: 8px;
	
	-webkit-box-shadow: none;
					box-shadow: none;	
}


.notice-success, div.updated,
div.notice-success.updated {
	border-color: #46b450;
	background: rgba(0,255,0,0.1);
}


.notice-error, div.error {
	background: rgba(255,0,0,0.1);
	border-color: #dc3232;
}

.notice-warning, div.warning {
	background: rgba(0,255,255,0.1);
	border-color: #ffb900;
}


.button.installing:before, 
.button.updating-message:before, 
.import-php .updating-message:before, 
.update-message p:before, 
.updating-message p:before {
	color: #ffb900;
}

.button.updated-message:before, .installed p:before, .updated-message p:before {
	color: #46b450;
}


.wrap .page-title-action:focus,
.wp-person a:focus .gravatar, a:focus, a:focus .media-icon img,
input[type=text]:focus, input[type=search]:focus, input[type=radio]:focus, input[type=tel]:focus, input[type=time]:focus, input[type=url]:focus, input[type=week]:focus, input[type=password]:focus, input[type=checkbox]:focus, input[type=color]:focus, input[type=date]:focus, input[type=datetime]:focus, input[type=datetime-local]:focus, input[type=email]:focus, input[type=month]:focus, input[type=number]:focus, select:focus, textarea:focus {
	-webkit-box-shadow: none;
	box-shadow: none;
	
	border-color: <?php echo $underscore_primary; ?>
}


.fixed .column-author, .fixed .column-date, .fixed .column-format, .fixed .column-links, .fixed .column-parent, .fixed .column-posts {
	width: 14%
}

.column-post_thumbs { 
	text-align: left; width:60px !important; overflow:hidden 
}
.column-post_thumbs img { 
	width: 100% 
}


#wp-content-editor-tools {
	background: transparent;
}


.wp-editor-tabs {
  position: absolute;
  bottom: 0;
  right: 0;	
	margin-top: 0;
	float: none;
}
.html-active .switch-html, #post-body-content .tmce-active .switch-tmce {
	border-bottom-color: #FFF;
}


#post-body-content .wp-media-buttons .button {
	font-size: 12px;
	margin-bottom: 10px;
}

#post-body-content .wp-media-buttons img {
	vertical-align: baseline;
}


.plugin-update-tr.active td, 
.plugins .active th.check-column {
	border-left: 5px solid #46b450;
}

.plugins .active td, .plugins .active th {
	backgroung: #FFF;
}

.plugins tr.inactive {
	background: #FDFDFD;
}

.plugins tr.inactive td > * {
	opacity: 0.5;
}

.plugins .active.update th.check-column, 
.plugins .active.update+.plugin-update-tr .plugin-update {
	border-left-width: 5px;	
}

.plugin-update-tr.inactive td, 
.plugins .inactive th.check-column {
	border-left: 5px solid #CCC;
}


#latest-comments {
	overflow:hidden;
}
.tagcloud {
	display:none;
}



#wpbody .acf-postbox.seamless > .acf-fields > .acf-tab-wrap .acf-tab-group li.active a {
	background: #FFF
}

.wp-dashboard-post-type {
	display: inline-block;
	background: #EFEFEF;
	padding: 3px 7px;
	min-width:auto !important;
	
	font-size: 10px;
	text-transform: uppercase;
	letter-spacing: 0.05em;
}



div#widgets-right .sidebar-name h2, div#widgets-right .sidebar-name h3 {
	font-size: 18px;
}
